
     <div class="container-xxl py-5">
        <div class="container">
            <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Explorer par secteur d'activité</h1>
            <div class="row g-4">
                <?php $__currentLoopData = $secteurActivites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secteurActivite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <a class="cat-item rounded p-4" href="">
                        <i class=" <?php echo e($secteurActivite->class); ?> "></i>
                        <h6 class="mb-3"> <?php echo e($secteurActivite->nom); ?> </h6>
                        <p class="mb-0">123 Vacances</p>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
<?php /**PATH C:\Users\HP\Documents\source\chirper\resources\views/front/secteuractivite.blade.php ENDPATH**/ ?>