<x-front-layout>
    <!-- Carousel Start -->

<!-- Carousel End -->


<!-- Search Start -->

<!-- Search End -->


<!-- Category Start -->


<!-- Category End -->


<!-- About Start -->

<!-- About End -->


<!-- Jobs Start -->
@include('front.listeofrre')
<!-- Jobs End -->


<!-- Testimonial Start -->

<!-- Testimonial End -->


</x-front-layout>
